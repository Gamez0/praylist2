package com.rozdoum.socialcomponents.main.usersList;

/**
 * Created by Alexey on 16.05.18.
 */
public interface UsersListType {
    int FOLLOWINGS = 115;
    int FOLLOWERS = 116;
}
